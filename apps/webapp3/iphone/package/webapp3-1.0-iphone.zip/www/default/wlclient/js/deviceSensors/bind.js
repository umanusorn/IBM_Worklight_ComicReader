
/* JavaScript content from wlclient/js/deviceSensors/bind.js in Common Resources */
/**
 * @license
 * Licensed Materials - Property of IBM
 * 5725-G92 (C) Copyright IBM Corp. 2006, 2013. All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
__Binder = function() {
	this.bind = function() {		
	};
	
	this.unbind = function() {		
	};


};

var Binder = new __Binder();
WL.App.setKeepAliveInBackground = Binder.bind;
